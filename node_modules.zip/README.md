# lambda-image-resizer
